sudo echo '<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1.0"> <title>Hello World Service</title> </head> <body> <h1>Hello. Is this the Deployment you are looking for?</h1> <h2>New Deployment - '${version}'</h2> </body> </html>' > /tmp/genericArtifactDemo/output

sudo cp /tmp/genericArtifactDemo/output /var/www/html/index.html
